/**
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Amazon Software License (the "License"). You may not use this file
 * except in compliance with the License. A copy of the License is located at
 *
 * http://aws.amazon.com/asl/
 *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
package com.amazon.alexa.avs.ui.headless;

import java.util.Locale;

import com.amazon.alexa.avs.AVSController;
import com.amazon.alexa.avs.config.DeviceConfig;
import com.amazon.alexa.avs.ui.LocaleUIHandler;
import com.amazon.alexa.avs.ui.controllers.LocaleViewController;

public class HeadlessLocaleView implements LocaleUIHandler {

    private LocaleViewController localeViewController;

    public HeadlessLocaleView(DeviceConfig config, AVSController controller) {
        localeViewController = new LocaleViewController(config, controller);
    }

    @Override
    public void handleLocaleChange(Locale locale) {
        localeViewController.handleLocaleChange(locale);
    }
}
